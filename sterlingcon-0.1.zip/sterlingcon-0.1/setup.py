from distutils.core import setup

setup(
    name='sterlingcon',
    version='0.1',
    packages=[''],
    url='https://github.com/anthony-valantra/sterlingpy',
    license='',
    author='anthony.valantra',
    author_email='anthony.valantra@live.com',
    description='package for connecting to Sterling version 9.3 and basic conversions between xml & dict'
)

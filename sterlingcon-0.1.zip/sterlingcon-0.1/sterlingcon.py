import requests
from xml.dom import minidom

url="localhost"
port="80"
traceLevel=0
def setupConfig(arg_url, arg_port, arg_traceLevel):
    global url
    global port
    global traceLevel
    url=arg_url
    port=arg_port
    traceLevel=arg_traceLevel

def parse_element(element):
    dict_data = dict()
    if element.nodeType == element.TEXT_NODE:
        dict_data['data'] = element.data
    if element.nodeType not in [element.TEXT_NODE, element.DOCUMENT_NODE,
                                element.DOCUMENT_TYPE_NODE]:
        for item in element.attributes.items():
            if (('Max' in item[0]) or ('Min' in item[0])):
                dict_data[item[0]] = float(item[1])
            else:
                dict_data[item[0]] = item[1]

    if element.nodeType not in [element.TEXT_NODE, element.DOCUMENT_TYPE_NODE]:
        for child in element.childNodes:
            child_name, child_dict = parse_element(child)

            if child_name in dict_data:
                try:
                    dict_data[child_name].append(child_dict)
                except AttributeError:
                    dict_data[child_name] = [dict_data[child_name], child_dict]
            else:
                dict_data[child_name] = child_dict
    return element.nodeName, dict_data

def dict2xml(d, root_node=None):
    wrap = False if None == root_node or isinstance(d, list) else True
    root = 'objects' if None == root_node else root_node
    root_singular = root[:-1] if 's' == root[-1] and None == root_node else root
    xml = ''
    children = []

    if isinstance(d, dict):
        for key, value in dict.items(d):
            if isinstance(value, dict):
                children.append(dict2xml(value, key))
            elif isinstance(value, list):
                children.append(dict2xml(value, key))
            else:
                xml = xml + ' ' + key + '="' + str(value) + '"'
    else:
        for value in d:
            children.append(dict2xml(value, root_singular))

    end_tag = '>' if 0 < len(children) else '/>'

    if wrap or isinstance(d, dict):
        xml = '<' + root + xml + end_tag

    if 0 < len(children):
        for child in children:
            xml = xml + child

        if wrap or isinstance(d, dict):
            xml = xml + '</' + root + '>'

    return xml


def callSterlingOFL(api_type,service,xml,template):
    return post_to_sterling(url, port, api_type, service, xml,template)


def post_to_sterling(host, port,api_type, service,xml,template):

    url = 'http://'+host+':'+port+'/smcfs/interop/InteropHttpServlet'
    progid = 'YFSEnvironment.progId=SC-NDM'
    interopapi = 'InteropApiName='+service
    flowtype = 'IsFlow=' + api_type
    invokeflow = 'InvokeFlow='+service
    service = 'ServiceName='+service
    locale = 'YFSEnvironment.locale='
    userid = 'YFSEnvironment.userId=yantra'
    password = 'YFSEnvironment.password='
    interopApiData = 'InteropApiData='+ xml
    template = 'TemplateData=' + template

    request = url + '?' + progid + '&' + interopapi + '&' + flowtype + '&' + invokeflow + '&' + service + '&' + locale + '&' + userid + '&' + password + '&' + interopApiData + '&' + template
    if traceLevel == 1:
        print url, interopapi, interopApiData

    r = requests.get(request)
    response = r.content

    if traceLevel == 1:
        print request

    if traceLevel == 1:
        print response

    return response

if __name__ == "__main__":

    print url+port
    setupConfig("loflqnasv05", "7001",0)
    print url + port
    print callSterlingOFL("N","getDBConnParams","<test/>","")
    print parse_element(minidom.parseString(callSterlingOFL("N","getDBConnParams","<test/>","")))[1]
